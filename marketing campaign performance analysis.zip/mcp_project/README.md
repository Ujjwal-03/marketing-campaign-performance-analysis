# Marketing Campaign Performance Analysis

End-to-end analytics project: 288 campaigns, 8 channels, 3 campaign types, 12 months (Apr-Mar).
Funnel KPIs (CTR, CPC, CPL, CAC, ROAS, ROI), channel/month/type comparison, revenue prediction model
and a budget re-allocation scenario.

> **Note:** the dataset is simulated (seeded script `generate_data.py`). Replace `data/campaigns.csv`
> with a real export (Google Ads, Meta Ads, CRM) to run the same pipeline on real data.

## Key Results
| Metric | Value |
|---|---|
| Total spend / revenue | Rs. 235.1 lakh / Rs. 731.1 lakh |
| Overall ROAS / ROI | 3.11x / 211% |
| Best channel (ROAS) | Email Marketing 8.36x |
| Worst channel (ROAS) | YouTube Ads 0.71x |
| Best campaign type | Retargeting (4.86x) |
| Best model | Random Forest, R2 = 0.865 |
| Re-allocation scenario | +10% revenue at same spend (3.11x -> 3.42x) |

## Project Structure
```
├── data/        campaigns.csv (raw), campaigns_clean.csv (with KPIs)
├── src/         generate_data.py, analysis.py, diagrams.py
├── outputs/     charts/ (14 PNG), results.json
├── docs/        full PDF project report
├── requirements.txt
└── README.md
```

## How to Run
```bash
pip install -r requirements.txt
cd src
python generate_data.py   # creates data/campaigns.csv
python analysis.py        # cleaning, KPIs, charts, model, scenario
python diagrams.py        # architecture / mechanism diagrams
```

## Charts
![Architecture](outputs/charts/d1_architecture.png)
![Mechanism](outputs/charts/d2_mechanism.png)
![ROAS](outputs/charts/c2_roas.png)
![Spend vs Revenue](outputs/charts/c1_spend_revenue.png)
![Monthly](outputs/charts/c4_monthly.png)
![Model](outputs/charts/c9_actual_pred.png)

## Tools
Python, Pandas, NumPy, Matplotlib, Scikit-learn, Git & GitHub.

## Author
Banke Bihari - PGDM, NIET Business School (Roll No. 2527270045, Section B)
