"""
generate_data.py
Creates a simulated marketing-campaign dataset (12 months, 8 channels, 3 campaign types).
Values follow realistic funnel rates; replace with real campaign exports for real use.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(7)

# channel: (cost per click INR, CTR, lead rate per click, conversion rate per lead, avg order value INR, budget scale)
CHANNELS = {
    "Google Search Ads": (28, 0.045, 0.10, 0.20, 4000, 1.4),
    "Facebook/Instagram": (14, 0.012, 0.06, 0.10, 3500, 1.3),
    "YouTube Ads": (20, 0.008, 0.04, 0.09, 3500, 0.9),
    "Email Marketing": (12, 0.035, 0.09, 0.25, 3800, 0.5),
    "SEO / Content": (6, 0.030, 0.05, 0.16, 4000, 0.6),
    "WhatsApp Campaign": (11, 0.060, 0.12, 0.18, 3200, 0.6),
    "LinkedIn Ads": (45, 0.006, 0.07, 0.12, 6000, 0.8),
    "Display Ads": (9, 0.004, 0.03, 0.07, 3000, 0.9),
}
TYPES = {"Brand Awareness": (0.6, 0.8), "Lead Generation": (1.0, 1.0), "Retargeting": (1.4, 1.2)}
MONTHS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]
SEASON = {"Oct": 1.25, "Nov": 1.30, "Dec": 1.10, "Mar": 1.05, "Jun": 0.92, "Jul": 0.90}

rows = []
for m_i, month in enumerate(MONTHS):
    for ch, (cpc, ctr, lr, cr, aov, scale) in CHANNELS.items():
        for ctype, (conv_mult, lead_mult) in TYPES.items():
            spend = float(rng.uniform(40000, 160000) * scale * rng.uniform(0.8, 1.2))
            if ctype == "Brand Awareness":
                spend *= 0.8
            clicks = int(spend / (cpc * rng.normal(1, 0.08)))
            impressions = int(clicks / (ctr * rng.normal(1, 0.08)))
            leads = int(rng.binomial(clicks, min(0.95, lr * lead_mult * rng.normal(1, 0.06))))
            p_conv = min(0.9, cr * conv_mult * SEASON.get(month, 1.0) * rng.normal(1, 0.06))
            conversions = int(rng.binomial(leads, p_conv))
            revenue = float(conversions * aov * rng.normal(1, 0.07))
            rows.append([f"CMP{1000 + len(rows)}", month, ch, ctype, round(spend), impressions,
                         clicks, leads, conversions, round(revenue)])

df = pd.DataFrame(rows, columns=["campaign_id", "month", "channel", "campaign_type", "spend",
                                 "impressions", "clicks", "leads", "conversions", "revenue"])

# a few missing values to demonstrate cleaning
for col, n in [("leads", 6), ("impressions", 5)]:
    df.loc[rng.choice(df.index, n, replace=False), col] = np.nan

df.to_csv("../data/campaigns.csv", index=False)
print(df.shape)
