"""
analysis.py
Cleaning -> KPI calculation -> EDA -> revenue model -> budget scenario -> charts
for the Marketing Campaign Performance Analysis project.
"""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

OUT = "../outputs/charts/"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
NAVY, TEAL, ORANGE, GREY, GOLD = "#1F3A5F", "#2A9D8F", "#E76F51", "#8D99AE", "#E9C46A"
MONTHS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]

# ---------- 1. Load & clean ----------
df = pd.read_csv("../data/campaigns.csv")
raw_missing = df.isna().sum().to_dict()

# a missing funnel value is rebuilt from the channel's typical rate
ch_ctr = (df.clicks / df.impressions).groupby(df.channel).median()
ch_lr = (df.leads / df.clicks).groupby(df.channel).median()
m = df.impressions.isna()
df.loc[m, "impressions"] = (df.loc[m, "clicks"] / df.loc[m, "channel"].map(ch_ctr)).round()
m = df.leads.isna()
df.loc[m, "leads"] = (df.loc[m, "clicks"] * df.loc[m, "channel"].map(ch_lr)).round()
df["month"] = pd.Categorical(df["month"], MONTHS, ordered=True)


def add_kpis(d):
    d = d.copy()
    d["CTR"] = d.clicks / d.impressions * 100
    d["CPC"] = d.spend / d.clicks
    d["CPL"] = d.spend / d.leads
    d["lead_to_sale"] = d.conversions / d.leads * 100
    d["CAC"] = d.spend / d.conversions
    d["ROAS"] = d.revenue / d.spend
    d["ROI"] = (d.revenue - d.spend) / d.spend * 100
    return d


df = add_kpis(df)
df.to_csv("../data/campaigns_clean.csv", index=False)


def agg(by):
    g = df.groupby(by, observed=True)[["spend", "impressions", "clicks", "leads", "conversions", "revenue"]].sum()
    g["CTR"] = g.clicks / g.impressions * 100
    g["CPC"] = g.spend / g.clicks
    g["CPL"] = g.spend / g.leads
    g["lead_to_sale"] = g.conversions / g.leads * 100
    g["CAC"] = g.spend / g.conversions
    g["ROAS"] = g.revenue / g.spend
    g["ROI"] = (g.revenue - g.spend) / g.spend * 100
    return g


ch = agg("channel").sort_values("ROAS", ascending=False)
mo = agg("month")
ty = agg("campaign_type")
tot = df[["spend", "impressions", "clicks", "leads", "conversions", "revenue"]].sum()
overall = {"spend": tot.spend, "revenue": tot.revenue, "ROAS": tot.revenue / tot.spend,
           "ROI": (tot.revenue - tot.spend) / tot.spend * 100, "CTR": tot.clicks / tot.impressions * 100,
           "CPC": tot.spend / tot.clicks, "CPL": tot.spend / tot.leads, "CAC": tot.spend / tot.conversions,
           "lead_to_sale": tot.conversions / tot.leads * 100}

# ---------- 2. Charts ----------
# C1 spend vs revenue by channel
fig, ax = plt.subplots(figsize=(6.6, 3.7))
x = np.arange(len(ch)); w = 0.38
ax.bar(x - w / 2, ch.spend / 1e5, w, color=NAVY, label="Spend")
ax.bar(x + w / 2, ch.revenue / 1e5, w, color=TEAL, label="Revenue")
ax.set_xticks(x); ax.set_xticklabels(ch.index, rotation=30, ha="right", fontsize=8)
ax.set_ylabel("INR lakh"); ax.set_title("Fig 4.1 Spend vs Revenue by Channel"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig(OUT + "c1_spend_revenue.png", dpi=200); plt.close(fig)

# C2 ROAS by channel
fig, ax = plt.subplots(figsize=(6.4, 3.6))
s = ch["ROAS"].sort_values()
cols = [ORANGE if v < 1 else (GOLD if v < 2 else TEAL) for v in s.values]
ax.barh(s.index, s.values, color=cols)
ax.axvline(1, color="black", ls="--", lw=1)
for i, v in enumerate(s.values):
    ax.text(v + 0.1, i, f"{v:.2f}x", va="center", fontsize=8)
ax.set_xlabel("ROAS (revenue per Rs. 1 spent)"); ax.set_xlim(0, s.max() * 1.15)
ax.set_title("Fig 4.2 Return on Ad Spend by Channel (dashed = break-even)")
fig.tight_layout(); fig.savefig(OUT + "c2_roas.png", dpi=200); plt.close(fig)

# C3 CTR and lead-to-sale rate by channel
fig, axs = plt.subplots(1, 2, figsize=(6.8, 3.4), sharey=True)
c3 = ch.sort_values("CTR")
axs[0].barh(c3.index, c3.CTR, color=NAVY); axs[0].set_title("Click-through rate (%)", fontsize=10)
c3b = ch.loc[c3.index]
axs[1].barh(c3b.index, c3b.lead_to_sale, color=ORANGE); axs[1].set_title("Lead-to-sale rate (%)", fontsize=10)
for a, col in zip(axs, ["CTR", "lead_to_sale"]):
    for i, v in enumerate(c3b[col]):
        a.text(v + 0.2, i, f"{v:.1f}", va="center", fontsize=7)
fig.suptitle("Fig 4.3 Engagement and Conversion by Channel", fontsize=10)
fig.tight_layout(); fig.savefig(OUT + "c3_ctr_conv.png", dpi=200); plt.close(fig)

# C4 monthly trend
fig, ax = plt.subplots(figsize=(6.6, 3.4))
ax.plot(mo.index.astype(str), mo.spend / 1e5, marker="o", color=NAVY, label="Spend")
ax.plot(mo.index.astype(str), mo.revenue / 1e5, marker="o", color=TEAL, label="Revenue")
ax.set_ylabel("INR lakh"); ax.set_title("Fig 4.4 Monthly Spend and Revenue Trend"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig(OUT + "c4_monthly.png", dpi=200); plt.close(fig)

# C5 CPL and CAC
fig, axs = plt.subplots(1, 2, figsize=(6.8, 3.4), sharey=True)
c5 = ch.sort_values("CAC")
axs[0].barh(c5.index, c5.CPL, color=GOLD); axs[0].set_title("Cost per lead (Rs.)", fontsize=10)
axs[1].barh(c5.index, c5.CAC, color=ORANGE); axs[1].set_title("Cost per customer (CAC, Rs.)", fontsize=10)
for a, col in zip(axs, ["CPL", "CAC"]):
    for i, v in enumerate(c5[col]):
        a.text(v + 5, i, f"{v:,.0f}", va="center", fontsize=7)
fig.suptitle("Fig 4.5 Cost Efficiency by Channel", fontsize=10)
fig.tight_layout(); fig.savefig(OUT + "c5_cpl_cac.png", dpi=200); plt.close(fig)

# C6 funnel
fig, ax = plt.subplots(figsize=(6.2, 3.2))
stages = ["Impressions", "Clicks", "Leads", "Customers"]
vals = [tot.impressions, tot.clicks, tot.leads, tot.conversions]
fcols = [NAVY, TEAL, GOLD, ORANGE]
wd = [v / vals[0] for v in vals]
wd = [max(w_, 0.06) for w_ in np.sqrt(wd)]
for i, (st, v, c, w_) in enumerate(zip(stages, vals, fcols, wd)):
    ax.barh(3 - i, w_, left=(1 - w_) / 2, color=c, height=0.8)
    ax.text(0.5, 3 - i, f"{st}: {v:,.0f}", ha="center", va="center", color="white" if i != 2 else "black",
            fontsize=8.5, fontweight="bold")
ax.axis("off"); ax.set_title("Fig 4.6 Overall Marketing Funnel")
fig.tight_layout(); fig.savefig(OUT + "c6_funnel.png", dpi=200); plt.close(fig)

# C7 campaign type
fig, axs = plt.subplots(1, 2, figsize=(6.6, 3.0))
axs[0].bar(ty.index, ty.ROAS, color=[GREY, TEAL, ORANGE]); axs[0].set_title("ROAS by campaign type", fontsize=10)
axs[1].bar(ty.index, ty.CAC, color=[GREY, TEAL, ORANGE]); axs[1].set_title("CAC (Rs.) by campaign type", fontsize=10)
for a in axs:
    a.tick_params(axis="x", labelsize=7.5)
fig.suptitle("Fig 4.7 Performance by Campaign Type", fontsize=10)
fig.tight_layout(); fig.savefig(OUT + "c7_type.png", dpi=200); plt.close(fig)

# C8 correlation heatmap
cc = df[["spend", "impressions", "clicks", "leads", "conversions", "revenue", "CTR", "CPC", "ROAS"]].corr().round(2)
fig, ax = plt.subplots(figsize=(6.2, 4.5))
im = ax.imshow(cc.values, cmap="RdBu_r", vmin=-1, vmax=1)
ax.set_xticks(range(len(cc))); ax.set_xticklabels(cc.columns, rotation=40, ha="right", fontsize=8)
ax.set_yticks(range(len(cc))); ax.set_yticklabels(cc.index, fontsize=8)
for i in range(len(cc)):
    for j in range(len(cc)):
        ax.text(j, i, f"{cc.values[i, j]:.2f}", ha="center", va="center", fontsize=7)
fig.colorbar(im, fraction=0.04); ax.set_title("Fig 4.8 Correlation Matrix of Campaign Metrics")
fig.tight_layout(); fig.savefig(OUT + "c8_corr.png", dpi=200); plt.close(fig)

# ---------- 3. Revenue model ----------
d = df.copy()
d["festive"] = d.month.isin(["Oct", "Nov", "Dec"]).astype(int)
X = pd.get_dummies(d[["spend", "channel", "campaign_type", "festive"]], columns=["channel", "campaign_type"],
                   drop_first=True)
y = d["revenue"] / 1e3  # in thousand INR
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42)

models = {"Linear Regression": LinearRegression(),
          "Random Forest": RandomForestRegressor(n_estimators=300, random_state=42)}
results, preds = {}, {}
for n, mdl in models.items():
    mdl.fit(X_tr, y_tr); p = mdl.predict(X_te); preds[n] = p
    results[n] = {"R2": round(r2_score(y_te, p), 4), "MAE": round(mean_absolute_error(y_te, p), 2),
                  "RMSE": round(float(np.sqrt(mean_squared_error(y_te, p))), 2)}
best = max(results, key=lambda k: results[k]["R2"])

fig, ax = plt.subplots(figsize=(4.6, 4.2))
ax.scatter(y_te, preds[best], s=16, alpha=0.7, color=TEAL)
lim = [0, max(y_te.max(), preds[best].max()) * 1.03]
ax.plot(lim, lim, color=ORANGE, ls="--", label="Perfect prediction")
ax.set_xlabel("Actual revenue (Rs. thousand)"); ax.set_ylabel("Predicted revenue (Rs. thousand)")
ax.set_title(f"Fig 5.1 Actual vs Predicted ({best})", fontsize=10); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig(OUT + "c9_actual_pred.png", dpi=200); plt.close(fig)

rf = models["Random Forest"]
imp = pd.Series(rf.feature_importances_, index=X.columns)
gi = pd.Series({"Spend": imp["spend"],
                "Channel": imp[[c for c in imp.index if c.startswith("channel_")]].sum(),
                "Campaign type": imp[[c for c in imp.index if c.startswith("campaign_type_")]].sum(),
                "Festive season": imp["festive"]}).sort_values()
fig, ax = plt.subplots(figsize=(6.0, 2.6))
ax.barh(gi.index, gi.values * 100, color=[GREY, GOLD, TEAL, NAVY])
for i, v in enumerate(gi.values * 100):
    ax.text(v + 0.7, i, f"{v:.1f}%", va="center", fontsize=8)
ax.set_xlabel("Importance (%)"); ax.set_xlim(0, gi.max() * 100 * 1.15)
ax.set_title("Fig 5.2 What Drives Revenue? (Random Forest importance)")
fig.tight_layout(); fig.savefig(OUT + "c10_importance.png", dpi=200); plt.close(fig)

# ---------- 4. Budget re-allocation scenario ----------
# shift 20% of spend from the 3 lowest-ROAS channels to the 3 highest-ROAS channels.
# assumption: the extra money earns only 70% of the receiving channel's current ROAS (diminishing returns).
low = list(ch.sort_values("ROAS").index[:3]); high = list(ch.index[:3])
shift = ch.loc[low, "spend"].sum() * 0.20
lost_rev = (ch.loc[low, "spend"] * 0.20 * ch.loc[low, "ROAS"]).sum()
w_high = ch.loc[high, "spend"] / ch.loc[high, "spend"].sum()
gained_rev = (shift * w_high * ch.loc[high, "ROAS"] * 0.70).sum()
new_rev = tot.revenue - lost_rev + gained_rev
scen = {"shift_amount": shift, "low": low, "high": high, "old_rev": tot.revenue, "new_rev": new_rev,
        "old_roas": tot.revenue / tot.spend, "new_roas": new_rev / tot.spend,
        "gain": new_rev - tot.revenue, "gain_pct": (new_rev / tot.revenue - 1) * 100}

fig, ax = plt.subplots(figsize=(5.2, 3.2))
ax.bar(["Current plan", "Re-allocated plan"], [tot.revenue / 1e5, new_rev / 1e5], color=[GREY, TEAL], width=0.5)
for i, v in enumerate([tot.revenue / 1e5, new_rev / 1e5]):
    ax.text(i, v + 5, f"Rs. {v:,.0f} L", ha="center", fontsize=9, fontweight="bold")
ax.set_ylim(0, new_rev / 1e5 * 1.18); ax.set_ylabel("Total revenue (INR lakh)")
ax.set_title("Fig 6.1 Budget Re-allocation Scenario (same total spend)", fontsize=10)
fig.tight_layout(); fig.savefig(OUT + "c11_scenario.png", dpi=200); plt.close(fig)

# ---------- 5. Save for the report ----------
def tolist(g, cols):
    return g.reset_index()[[g.index.name] + cols].values.tolist()


out = {"n_rows": len(df), "raw_missing": raw_missing, "overall": overall, "best": best, "results": results,
       "channel": tolist(ch, ["spend", "revenue", "CTR", "CPC", "CPL", "lead_to_sale", "CAC", "ROAS", "ROI"]),
       "month": tolist(mo, ["spend", "revenue", "ROAS"]),
       "type": tolist(ty, ["spend", "revenue", "CTR", "lead_to_sale", "CAC", "ROAS"]),
       "totals": tot.to_dict(), "importance": {k: round(v * 100, 1) for k, v in gi.sort_values(ascending=False).items()},
       "scenario": scen, "corr_rev": cc["revenue"].to_dict()}
json.dump(out, open("../outputs/results.json", "w"), indent=2, default=str)
print(json.dumps({k: out[k] for k in ["overall", "results", "importance", "scenario"]}, indent=1, default=str))
print(ch[["spend", "revenue", "CTR", "CPL", "lead_to_sale", "CAC", "ROAS"]].round(2))
print(mo[["spend", "revenue", "ROAS"]].round(2)); print(ty[["CTR", "lead_to_sale", "CAC", "ROAS"]].round(2))
print(cc["revenue"])
