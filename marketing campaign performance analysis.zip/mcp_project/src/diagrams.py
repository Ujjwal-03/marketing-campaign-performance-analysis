"""diagrams.py - architecture, KPI-mechanism and GitHub-flow diagrams for the report."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = "../outputs/charts/"
NAVY, TEAL, ORANGE, LIGHT, GREY, GOLD = "#1F3A5F", "#2A9D8F", "#E76F51", "#EAF4F3", "#8D99AE", "#E9C46A"


def box(ax, x, y, w, h, text, fc=NAVY, tc="white", fs=8.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fc, ec="none"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", color=tc, fontsize=fs,
            fontweight="bold", linespacing=1.3)


def arrow(ax, x1, y1, x2, y2, color=GREY):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12, color=color, lw=1.6))


# ---------- 1. architecture ----------
fig, ax = plt.subplots(figsize=(7.0, 5.2))
ax.set_xlim(0, 10); ax.set_ylim(0, 8); ax.axis("off")
box(ax, 0.3, 6.4, 2.6, 1.2, "1. DATA SOURCE\nCampaign records\n(288 campaigns)", TEAL)
box(ax, 3.7, 6.4, 2.6, 1.2, "2. DATA CLEANING\nFix missing funnel\nvalues", NAVY)
box(ax, 7.1, 6.4, 2.6, 1.2, "3. KPI CALCULATION\nCTR, CPL, CAC,\nROAS, ROI", NAVY)
arrow(ax, 2.9, 7.0, 3.7, 7.0); arrow(ax, 6.3, 7.0, 7.1, 7.0)
box(ax, 7.1, 4.2, 2.6, 1.2, "4. ANALYSIS\nChannel, month,\ncampaign type", NAVY)
arrow(ax, 8.4, 6.4, 8.4, 5.4)
box(ax, 3.7, 4.2, 2.6, 1.2, "5. REVENUE MODEL\nLinear Regression\nRandom Forest", ORANGE)
arrow(ax, 7.1, 4.8, 6.3, 4.8)
box(ax, 0.3, 4.2, 2.6, 1.2, "6. EVALUATION\nR2, MAE, RMSE", NAVY)
arrow(ax, 3.7, 4.8, 2.9, 4.8)
box(ax, 0.3, 2.0, 2.6, 1.2, "7. BUDGET SCENARIO\nShift spend to\nhigh-ROAS channels", GOLD, tc="black")
arrow(ax, 1.6, 4.2, 1.6, 3.2)
box(ax, 3.7, 2.0, 2.6, 1.2, "8. INSIGHTS AND\nRECOMMENDATIONS", TEAL)
arrow(ax, 2.9, 2.6, 3.7, 2.6)
box(ax, 7.1, 2.0, 2.6, 1.2, "9. GITHUB\nDEPLOYMENT\nCode + README + report", NAVY)
arrow(ax, 6.3, 2.6, 7.1, 2.6)
ax.add_patch(FancyBboxPatch((0.3, 0.3), 9.4, 1.0, boxstyle="round,pad=0.02,rounding_size=0.12", fc=LIGHT, ec=TEAL, lw=1.2))
ax.text(5, 0.8, "Tools: Python | Pandas | NumPy | Matplotlib | Scikit-learn | Git & GitHub", ha="center",
        va="center", fontsize=9, color=NAVY, fontweight="bold")
ax.set_title("Fig 3.1 System Architecture / Workflow of the Project", fontsize=10.5, color=NAVY, pad=6)
fig.tight_layout(); fig.savefig(OUT + "d1_architecture.png", dpi=200); plt.close(fig)

# ---------- 2. KPI mechanism ----------
fig, ax = plt.subplots(figsize=(7.0, 4.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
stages = [("SPEND", "Rs. invested", NAVY), ("IMPRESSIONS", "people reached", TEAL), ("CLICKS", "people interested", GOLD),
          ("LEADS", "enquiries", ORANGE), ("CUSTOMERS", "orders", NAVY), ("REVENUE", "sales value", TEAL)]
for i, (a, b, c) in enumerate(stages):
    x = 0.2 + i * 1.62
    box(ax, x, 4.6, 1.4, 1.5, f"{a}\n\n{b}", c, tc="black" if c == GOLD else "white", fs=6.6)
    if i < len(stages) - 1:
        arrow(ax, x + 1.4, 5.35, x + 1.62, 5.35)
kp = [("CTR = Clicks / Impressions", 1.9), ("CPC = Spend / Clicks", 3.55), ("CPL = Spend / Leads", 5.2),
      ("Lead-to-sale = Customers / Leads", 6.85), ("CAC = Spend / Customers", 8.5)]
ax.text(5, 3.85, "KPI formulas", ha="center", fontsize=9, fontweight="bold", color=NAVY)
for k, (t, _) in enumerate(kp):
    box(ax, 0.3 + (k % 3) * 3.25, 2.55 - (k // 3) * 1.05, 3.0, 0.8, t, TEAL if k % 2 == 0 else NAVY, fs=6.9)
box(ax, 6.8, 1.5, 3.0, 0.8, "ROAS = Revenue / Spend", ORANGE, fs=8)
ax.text(5, 0.5, "ROI % = (Revenue - Spend) / Spend x 100", ha="center", fontsize=9, fontweight="bold", color=NAVY)
ax.set_title("Fig 3.2 Working Mechanism: Marketing Funnel and KPI Formulas", fontsize=10.5, color=NAVY, pad=6)
fig.tight_layout(); fig.savefig(OUT + "d2_mechanism.png", dpi=200); plt.close(fig)

# ---------- 3. GitHub flow ----------
fig, ax = plt.subplots(figsize=(7.0, 1.9))
ax.set_xlim(0, 10); ax.set_ylim(0, 2.6); ax.axis("off")
steps = ["Local project\nfolder", "git init\ngit add .", "git commit\n-m message", "Create repo\non GitHub", "git push\norigin main"]
for i, s in enumerate(steps):
    x = 0.1 + i * 2.0
    box(ax, x, 0.7, 1.7, 1.2, s, NAVY if i % 2 == 0 else TEAL, fs=8)
    if i < 4:
        arrow(ax, x + 1.7, 1.3, x + 2.0, 1.3)
ax.set_title("Fig 7.1 GitHub Deployment Flow", fontsize=10.5, color=NAVY, pad=2)
fig.tight_layout(); fig.savefig(OUT + "d3_github.png", dpi=200); plt.close(fig)
print("ok")
